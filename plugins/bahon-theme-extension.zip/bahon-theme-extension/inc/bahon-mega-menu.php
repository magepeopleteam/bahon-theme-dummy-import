<?php
/********************************************
Mega menu post type
********************************************/
 
function bahon_mega_menu() {

    $labels = array(
        'name'                => _x( 'Mega Menu', 'Post Type General Name', 'bahon-theme-extension' ),
        'singular_name'       => _x( 'Mega Menu', 'Post Type Singular Name', 'bahon-theme-extension' ),
        'all_items'           => __( 'All Mega Menu', 'bahon-theme-extension' ),
        'view_item'           => __( 'View Mega Menu', 'bahon-theme-extension' ),
        'add_new_item'        => __( 'Add New Mega Menu', 'bahon-theme-extension' ),
        'add_new'             => __( 'Add New', 'bahon-theme-extension' ),
        'edit_item'           => __( 'Edit Mega Menu', 'bahon-theme-extension' ),
        'update_item'         => __( 'Update Mega Menu', 'bahon-theme-extension' ),
        'search_items'        => __( 'Search Mega Menu', 'bahon-theme-extension' ),
        'not_found'           => __( 'Not Found', 'bahon-theme-extension' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'bahon-theme-extension' ),
    );
     
    $args = array(
        'label'               => __( 'Mega Menu', 'bahon-theme-extension' ),
        'description'         => __( 'Shows Mega Menu', 'bahon-theme-extension' ),
        'labels'              => $labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => true,
        'show_in_rest'        => true,
		'menu_icon'           => 'dashicons-menu',

    );
     
    // Registering Post Type
    register_post_type( 'mega-menu', $args );
 
}

add_action( 'init', 'bahon_mega_menu', 0 );