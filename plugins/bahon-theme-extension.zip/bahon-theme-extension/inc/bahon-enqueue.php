<?php
/* ------------------------------------------------------------------------ */
/* Enqueue Fonts */
/* ------------------------------------------------------------------------ */
function vtc_enqueue()
  {
    wp_enqueue_style('flaticon', BAHON_THEME_EXTENSION_ASSET . '/fonts/flaticon/flaticon.css');
  }
add_action('wp_enqueue_scripts', 'vtc_enqueue', 1);