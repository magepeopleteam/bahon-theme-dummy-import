<?php
/*
Plugin Name: Bahon Theme Extension
Plugin URI: https://mage-people.com
Description: The Extension of the Bahon theme - Extend your website features with Bahon Theme Extension.
Version: 1.0
Author: MagePeople Team
Author URI: https://mage-people.com
Text Domain: bahon-theme-extension
Domain Path: /languages/
*/

define( 'BAHON_THEME_EXTENSION_VERSION', '1.0' );
define( 'BAHON_THEME_EXTENSION__FILE__', __FILE__ );
define( 'BAHON_THEME_EXTENSION_DIR_URL', plugin_dir_url( BAHON_THEME_EXTENSION__FILE__ ) );
define( 'BAHON_THEME_EXTENSION_INC', trailingslashit( BAHON_THEME_EXTENSION_DIR_URL . 'inc' ) );
define( 'BAHON_THEME_EXTENSION_ASSET', trailingslashit( BAHON_THEME_EXTENSION_DIR_URL . 'asset' ) );

#-----------------------------------------------------------------
# Load Bahon Metabox Functions
#-----------------------------------------------------------------

require_once('inc/bahon-metabox.php' );

#-----------------------------------------------------------------
# Load Bahon Mega-Menu Function
#-----------------------------------------------------------------

require_once('inc/bahon-mega-menu.php' );

#-----------------------------------------------------------------
# Load Bahon Enqueue Function
#-----------------------------------------------------------------

require_once('inc/bahon-enqueue.php' );