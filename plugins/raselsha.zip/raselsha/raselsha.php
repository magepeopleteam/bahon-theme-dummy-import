<?php
/**
 * Plugin Name: raselsha
 * Plugin URI: https://shahadat.com.bd
 * Version: 1.0
 * Description: Description
 * Author: shahadat
 * Author URI: https:shahadat.com.bd
 * Lisense: GPL v2 or later
 * Lisense URI: https:shahadat.com.bd
 *  
 */