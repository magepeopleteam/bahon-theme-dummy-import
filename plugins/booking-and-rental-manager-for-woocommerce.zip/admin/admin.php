<?php
if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
require_once(dirname(__DIR__) . '/admin/cpt.php');
require_once(dirname(__DIR__) . '/admin/meta.php');
require_once(dirname(__DIR__) . '/admin/taxonomy.php');
require_once(dirname(__DIR__) . '/admin/settings.php');