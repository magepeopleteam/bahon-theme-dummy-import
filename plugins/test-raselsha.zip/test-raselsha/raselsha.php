<?php
/**
 * Plguin Name: raselsha
 * plugin Uri: https:shahadat.com.bd
 * Version: 1.0
 * Descriptions: test
 * Author: shahadat
 * Authoer URI: https:shahadat.com.bd
 * Lisense: GPL v2 or later
 * Lisense URI: https:shahadat.com.bd
 *  
 */