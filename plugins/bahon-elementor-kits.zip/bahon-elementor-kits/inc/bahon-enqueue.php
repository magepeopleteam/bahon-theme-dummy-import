<?php

/*****************************************************
Enqueue scripts
******************************************************/

function bahon_ext_enqueue(){
	wp_enqueue_style('bahon-elementor-style', BAHON_ELEMENTOR_KITS_ASSETS . 'css/style.css?v='.BAHON_ELEMENTOR_KITS_VERSION);
	wp_enqueue_style('bahon-bootstrap-grid', BAHON_ELEMENTOR_KITS_ASSETS . 'css/bootstrap-grid.min.css?v='.BAHON_ELEMENTOR_KITS_VERSION);	
	wp_enqueue_style('bahon-lightbox', BAHON_ELEMENTOR_KITS_ASSETS . 'css/lightbox.css?v='.BAHON_ELEMENTOR_KITS_VERSION);
	wp_enqueue_script('bahon-custom', BAHON_ELEMENTOR_KITS_ASSETS . 'js/bahon.js?v='.BAHON_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
	wp_enqueue_script('bahon-multi-countdown', BAHON_ELEMENTOR_KITS_ASSETS . 'js/multi-countdown.js?v='.BAHON_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
	wp_enqueue_script('bahon-lightbox', BAHON_ELEMENTOR_KITS_ASSETS . 'js/lightbox.min.js?v='.BAHON_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
}

add_action('wp_enqueue_scripts', 'bahon_ext_enqueue');
