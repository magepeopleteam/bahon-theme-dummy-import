<?php

defined( 'ABSPATH' ) || die();

class Bahon_Icons_Manager {

    public static function init() {
        add_filter( 'elementor/icons_manager/additional_tabs', [ __CLASS__, 'add_bahon_icons_tab' ] );
    }

    public static function add_bahon_icons_tab( $tabs ) {
        $tabs['bahon-icons'] = [
            'name' => 'bahon-icons',
            'label' => __( 'Bahon Flaticons', 'bahon-elementor-addons' ),
            'url' => BAHON_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/flaticon.css?v='.BAHON_ELEMENTOR_KITS_VERSION,
            'enqueue' => [ BAHON_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/flaticon.css?v='.BAHON_ELEMENTOR_KITS_VERSION ],
            'prefix' => 'flaticon-',
            'labelIcon' => 'flaticon-setting',
            'ver' => BAHON_ELEMENTOR_KITS_VERSION,
            'fetchJson' => BAHON_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/bahon-flat-icons.js?v=' . BAHON_ELEMENTOR_KITS_VERSION,
            'native' => false,
        ];
        return $tabs;
    }
}

Bahon_Icons_Manager::init();