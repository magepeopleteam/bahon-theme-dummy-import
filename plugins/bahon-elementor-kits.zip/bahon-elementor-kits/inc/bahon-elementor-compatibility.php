<?php
/**
 * Elementor Backward Compatibility Helper
 * 
 * Provides backward compatibility for Elementor schemes (deprecated in 3.0)
 * Works with both Elementor 2.x (with schemes) and Elementor 3.x+ (without schemes)
 * 
 * @package Bahon_Elementor_Kits
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Check if Elementor schemes are available (Elementor < 3.0)
 * 
 * @return bool True if schemes are available
 */
function bahon_elementor_has_schemes() {
	return class_exists( 'Elementor\Core\Schemes\Typography' );
}

/**
 * Get typography scheme value for backward compatibility
 * 
 * @param int $scheme_number The scheme number (1-4), defaults to 3
 * @return mixed Scheme constant value or null
 */
function bahon_get_typography_scheme( $scheme_number = 3 ) {
	if ( ! bahon_elementor_has_schemes() ) {
		return null;
	}
	
	$schemes = [
		1 => defined( 'Elementor\Core\Schemes\Typography::TYPOGRAPHY_1' ) ? \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1 : 1,
		2 => defined( 'Elementor\Core\Schemes\Typography::TYPOGRAPHY_2' ) ? \Elementor\Core\Schemes\Typography::TYPOGRAPHY_2 : 2,
		3 => defined( 'Elementor\Core\Schemes\Typography::TYPOGRAPHY_3' ) ? \Elementor\Core\Schemes\Typography::TYPOGRAPHY_3 : 3,
		4 => defined( 'Elementor\Core\Schemes\Typography::TYPOGRAPHY_4' ) ? \Elementor\Core\Schemes\Typography::TYPOGRAPHY_4 : 4,
	];
	
	return isset( $schemes[$scheme_number] ) ? $schemes[$scheme_number] : $schemes[3];
}

/**
 * Add typography control with backward compatibility
 * Usage: Call this instead of directly calling add_group_control for typography
 * 
 * @param object $widget The widget instance
 * @param array $options Typography control options
 */
function bahon_add_typography_control( $widget, $options ) {
	// Add scheme for backward compatibility with Elementor < 3.0
	if ( bahon_elementor_has_schemes() && ! isset( $options['scheme'] ) ) {
		$options['scheme'] = bahon_get_typography_scheme( 3 );
	}
	
	$widget->add_group_control(
		\Elementor\Group_Control_Typography::get_type(),
		$options
	);
}

