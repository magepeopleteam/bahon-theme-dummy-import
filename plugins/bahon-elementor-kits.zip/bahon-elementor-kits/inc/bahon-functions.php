<?php

/******************************************************
Bahon Blog Meta functions
*******************************************************/

function vek_blog_author_meta(){

	$author_first_name = get_the_author_meta('first_name');	
	$author_display_name = get_the_author_meta('display_name');
	$author_meta = '<span><i class="fas fa-user"></i> '; 
	if($author_first_name){
		$author_meta .= esc_attr($author_first_name);
	} else {
		$author_meta .= esc_attr($author_display_name);
	}
	$author_meta .='</span>';
	return $author_meta; //escaped already
}

function vek_blog_wp_date_meta(){

	$wp_date_format = '<span class="post-date"><i class="far fa-calendar-alt"></i> 
					'.esc_attr(get_the_date()).'</span>';
	return $wp_date_format; //escaped already	 			
}

function vek_blog_style_date_meta(){

	$archive_month = get_the_time('M'); 
	$archive_day   = get_the_time('d'); 
	$archive_year  = get_the_time('Y'); 
	$theme_date_format = '<span class="post-date"><i class="far fa-calendar-alt"></i> 
						'. esc_attr($archive_month).' '. esc_attr($archive_day).', '. esc_attr($archive_year).'</span>';	
	return $theme_date_format; //escaped already					
}

function vek_blog_comments_meta($postid){
	
	$comments_meta = '';
		if ( comments_open($postid) ) {
				$comments_meta .= '<span><i class="fas fa-comments"></i> ';
				$comments_meta .= '<a href="'.get_comments_link().'">';
			if ( get_comments_number($postid) == 0 ) {
				$comments_meta .= esc_html__('No Comments','bahon-elementor-kits');
			} elseif ( get_comments_number($postid) > 1 ) {
				$comments_meta .= get_comments_number($postid) . esc_html__(' Comments','bahon-elementor-kits');
			} else {
				$comments_meta .= esc_html__('1 Comment','bahon-elementor-kits');
			}
				$comments_meta .= '</a>';
				$comments_meta .= '</span>';
		}
	return $comments_meta; //escaped already
}

function vek_blog_content($content_limit) {

    $content = explode(' ', get_the_content(), $content_limit);

    if (count($content) >= $content_limit) {

        array_pop($content);
        $content = implode(" ", $content) . '...';

    } else {

        $content = implode(" ", $content);
    }

    $content = preg_replace('/\[.+\]/','', $content);
    $content = apply_filters('the_content', $content); 
    $content = str_replace(']]>', ']]&gt;', $content);

    return $content;
}

function vek_blog_excerpt($excerpt_limit) {

      $excerpt = explode(' ', get_the_excerpt(), $excerpt_limit);

      if (count($excerpt) >= $excerpt_limit) {

          array_pop($excerpt);
          $excerpt = implode(" ", $excerpt) . '...';
      } else {

          $excerpt = implode(" ", $excerpt);
      }

      $excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);

      return $excerpt;
}

function vek_blog_get_categories() {
 
  $list  = array( '0' => esc_html__('All','bahon-elementor-kits') );
  $categories = get_categories();
   
  foreach( $categories as $category ){

    $list[$category->term_id] = $category->name;
  }

  return $list;
}

/******************************************************
Bahon Subscribe Ajax Callback function
*******************************************************/

function bahon_subscribe_callback(){

    $theme_option = get_option('theme_option_data');

    if (isset($_POST["email"])) {
        $email = trim($_POST["email"]);
    }else{
        $email = '';
    }

    if (isset($_POST["api"])) {
        $api = trim($_POST["api"]);
    }elseif($theme_option['mailchimp_apikey']){
        $api = $theme_option['mailchimp_apikey'];
    }else{
        $api = '';
    }

    if (isset($_POST["listid"])) {
        $list_id = trim($_POST["listid"]);
    }elseif($theme_option['mailchimp_listid']){
        $list_id = $theme_option['mailchimp_listid'];
    }else{
        $list_id = '';
    }

    if (isset($_POST["double_optin"])) {
        $double_optin = trim($_POST["double_optin"]);
    }elseif($theme_option['mailchimp_optin'] == 1){
        $double_optin = true;
    }else{
        $double_optin = true;
    }

    $MailChimp = new MailChimp($api);

    $args = array(
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode('user:' . $api),
            'Access-Control-Allow-Origin' => '*'
        )
    );

    // MailChimp API URL  
    $memberID         = md5(strtolower($email));
    $dataCenter       = substr($api, strpos($api, '-') + 1);
    $url             = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $list_id . '/members/' . $memberID;
    $response         = wp_remote_get($url, $args);
    $body             = json_decode(wp_remote_retrieve_body($response));
    $mailchimp_status = $body->status;

    if ($mailchimp_status == 'subscribed') {
        print json_encode(esc_html__('You are already subscribed. Thankyou!', 'bahon-elementor-kits'));
    } else {
        $mailchimp_result = $MailChimp->call('lists/subscribe', array(
            'id' => $list_id,
            'email' => array(
                'email' => $email
            ), 
            'double_optin' => $double_optin,
            'update_existing' => true,
            'send_welcome' => true
        ));

        if (isset($mailchimp_result['leid'])) {
            print json_encode(esc_html__('Thank You for Subscribing!', 'bahon-elementor-kits'));
        } else {
            print json_encode(esc_html__('Please, Input a valid email!', 'bahon-elementor-kits'));
        }
    }

    wp_die();

}

add_action( 'wp_ajax_bahon_subscribe_callback', 'bahon_subscribe_callback' );
add_action( 'wp_ajax_nopriv_bahon_subscribe_callback', 'bahon_subscribe_callback' );

/******************************************************
Bahon Contact Form Ajax Callback function
*******************************************************/

function bahon_contact_form_callback(){

    if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['message']))
    {
        $error = '';

        if( empty( $_POST['name'] ) ){
         $error .= '<p class="error alert alert-warning">'.esc_html__("Enter Name", "bahon-elementor-kits").'</p>';        
        }

        if( empty( $_POST['email'] ) ){
         $error .= '<p class="error alert alert-warning">'.esc_html__("Enter Email", "bahon-elementor-kits").'</p>';        
        }elseif( !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) ){
         $error .= '<p class="error alert alert-warning">'.esc_html__("Enter Valid Email", "bahon-elementor-kits").'</p>';           
        }

        if( empty( $_POST['message'] ) ){
         $error .= '<p class="error alert alert-warning">'.esc_html__("Enter Message", "bahon-elementor-kits").'</p>';        
        }

        if( empty( $error ) ){        
            $name = strip_tags(trim($_POST['name']));
            $email = strip_tags(trim($_POST['email']));
            $sendermessage = strip_tags(trim($_POST['message']));
            $subject = strip_tags(trim($_POST['subject']));
            $recipient = strip_tags(trim($_POST['recipient']));
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            //Output in receiver email
            $message = 'Sender-Message: ' .$sendermessage ."\r\n";
            $message.= 'Sender-name: '. $name ."\r\n";
            $message.= 'Sender-email: '. $email ."\r\n";
            $mail = wp_mail($recipient, $subject, $message, $headers);
            
            if($mail){
                echo '<p class="error alert alert-warning">'.esc_html__("Thank You for Contacting us!", "bahon-elementor-kits").'</p>';
            }else{
                echo '<p class="error alert alert-warning">'.esc_html__("Sorry! Something is wrong. Please try again!", "bahon-elementor-kits").'</p>';
            }
        }else{
            echo $error ;
        }    
    }

wp_die();
}

add_action( 'wp_ajax_bahon_contact_form_callback', 'bahon_contact_form_callback' );
add_action( 'wp_ajax_nopriv_bahon_contact_form_callback', 'bahon_contact_form_callback' );

/******************************************************
Define ajax URL in front-end head tag
*******************************************************/

function vek_ajaxurl() {

   echo '<script type="text/javascript">
           var ajaxurl = "' . admin_url('admin-ajax.php') . '";
         </script>';
}

add_action('wp_head', 'vek_ajaxurl');