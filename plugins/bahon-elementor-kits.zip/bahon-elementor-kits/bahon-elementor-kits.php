<?php
/*
Plugin Name: Bahon Elementor Kits
Plugin URI: https://mage-people.com
Description: Widgets for Elementor
Version: 1.0
Author: MagePeople Team
Author URI: https://mage-people.com
Text Domain: bahon-elementor-kits
Domain Path: /languages/
*/

define( 'BAHON_ELEMENTOR_KITS_VERSION', '1.0' );
define( 'BAHON_ELEMENTOR_KITS__FILE__', __FILE__ );
define( 'BAHON_ELEMENTOR_KITS_DIR_URL', plugin_dir_url( BAHON_ELEMENTOR_KITS__FILE__ ) );
define( 'BAHON_ELEMENTOR_KITS_ASSETS', trailingslashit( BAHON_ELEMENTOR_KITS_DIR_URL . 'assets' ) );

#-----------------------------------------------------------------
# Load Bahon Functions
#-----------------------------------------------------------------

require_once 'inc/bahon-functions.php';

#-----------------------------------------------------------------
# Load Scripts
#-----------------------------------------------------------------

require_once 'inc/bahon-enqueue.php';

#-----------------------------------------------------------------
# Load Shortcodes
#-----------------------------------------------------------------

require_once 'inc/bahon-shortcodes.php';

#-----------------------------------------------------------------
# Load Elementor Widgets
#-----------------------------------------------------------------

require_once 'modules/elementor-elements/elementor.php';

#-----------------------------------------------------------------
# Load Bahon Icons
#-----------------------------------------------------------------

require_once 'inc/bahon-icons.php';

#-----------------------------------------------------------------
# Load Bahon Subscribe
#-----------------------------------------------------------------

require_once 'inc/bahon-class-subscribe.php';