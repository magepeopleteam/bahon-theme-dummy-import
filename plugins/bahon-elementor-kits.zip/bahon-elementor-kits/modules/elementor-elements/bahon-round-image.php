<?php

namespace Bahon\Widgets;



use Elementor\Widget_Base;

use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



/**

 * @since 1.1.0

 */

class BahonRoundImageWidget extends Widget_Base {



	public function get_name() {

		return 'bahon-round-image-widget';

	}



	public function get_title() {

		return __( 'Bahon Round Image', 'bahon-elementor-kits' );

	}



	public function get_icon() {

		return 'eicon-image';

	}



	public function get_categories() {

		return [ 'bahon-elements' ];

	}



	protected function _register_controls() {



		$this->start_controls_section(

			'bahon_round_image_settings',

			[

				'label' => __( 'Bahon Round Image Settings', 'bahon-elementor-kits' ),

				'tab' => Controls_Manager::TAB_CONTENT,

			]

		);



		$this->add_control(

			'bahon_round_image',

			[

				'label' => __( 'Choose Image', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::MEDIA,

				'default' => [

					'url' => 'https://bahon.com/demo-one/wp-content/uploads/sites/2/2021/08/about-img-1.jpg',

				],

			]

		);



		$this->add_control(

			'bahon_bg_animation_image',

			[

				'label' => __( 'Choose Background Animation Image', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::MEDIA,

				'default' => [

					'url' => 'https://bahon.com/demo-one/wp-content/uploads/sites/2/2021/08/shape-2.png',

				],

			]

		);

		$this->add_group_control(

			\Elementor\Group_Control_Border::get_type(),

			[

				'name' => 'bahon_round_image_border',

				'label' => __( 'Border', 'bahon-elementor-kits' ),

				'selector' => '{{WRAPPER}} .bahon-elementor-round-image-widget img',

			]

		);

	    $this->add_control(

	    	'bahon_round_image_border_radius',

	    	 [

	    	 	'label' => __('Border Radius', 'bahon-elementor-kits'), 

	    	 	'type' => Controls_Manager::DIMENSIONS, 

	    	 	'size_units' => ['px', '%'], 

	    	 	'selectors' => [

	    	 		'{{WRAPPER}} img ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

	    	 	]

	    	]

	    );

        $this->add_group_control(

        	\Elementor\Group_Control_Box_Shadow::get_type(), 

        	[

        		'name' => 'bahon_round_image_box_shadow', 

        		'selector' => '{{WRAPPER}}  img',

        	]

        );



		$this->add_control(

			'bahon_round_image_width',

			[

				'label' => __( 'Image Size', 'bahon-elementor-kits' ),

				'description' => __( 'Example: 100px or 50%', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::TEXT,

				'default' => '400px',

	    	 	'selectors' => [

	    	 		'{{WRAPPER}} img ' => 'width: {{VALUE}}',

	    	 	]

			]

		);



		$this->add_control(

			'bahon_animated_image_rotatation_start',

			[

				'label' => __( 'Animated image Rotatation Start From Degree', 'bahon-elementor-kits' ),

				'description' => __( 'Example: 0deg', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::TEXT,

				'default' => '0deg'

			]

		);

		$this->add_control(

			'bahon_animated_image_rotatation_end',

			[

				'label' => __( 'Animated image Rotatation End To Degree', 'bahon-elementor-kits' ),

				'description' => __( 'Example: 5deg or -5deg', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::TEXT,

				'default' => '5deg'

			]

		);

        $this->end_controls_section();

	

	}



	protected function render() {



		$settings = $this->get_settings_for_display();

		$bahon_round_image = $settings['bahon_round_image']['url'];

		$bahon_bg_animation_image = $settings['bahon_bg_animation_image']['url'];

		$bahon_animated_image_rotatation_start = $settings['bahon_animated_image_rotatation_start'];

		$bahon_animated_image_rotatation_end = $settings['bahon_animated_image_rotatation_end'];



		if($bahon_bg_animation_image){

			echo "

			<style>

            {{WRAPPER}} .bahon-elementor-round-image-widget:before{background-image:url(".$bahon_bg_animation_image.");}

			</style>

			";

		}

		if($bahon_animated_image_rotatation_start && $bahon_animated_image_rotatation_end){

			echo "

			<style>

				@keyframes dizzling{

				    0%{

				        -webkit-transform: rotate(".$bahon_animated_image_rotatation_start.");

				        -moz-transform: rotate(".$bahon_animated_image_rotatation_start.");

				        -ms-transform: rotate(".$bahon_animated_image_rotatation_start.");

				        -o-transform: rotate(".$bahon_animated_image_rotatation_start.");

				        transform: rotate(".$bahon_animated_image_rotatation_start.");

				    }

				    50%{

				        -webkit-transform: rotate(".$bahon_animated_image_rotatation_end.");

				        -moz-transform: rotate(".$bahon_animated_image_rotatation_end.");

				        -ms-transform: rotate(".$bahon_animated_image_rotatation_end.");

				        -o-transform: rotate(".$bahon_animated_image_rotatation_end.");

				        transform: rotate(".$bahon_animated_image_rotatation_end.");

				    }

				    100%{

				        -webkit-transform: rotate(".$bahon_animated_image_rotatation_start."0);

				        -moz-transform: rotate(".$bahon_animated_image_rotatation_start.");

				        -ms-transform: rotate(".$bahon_animated_image_rotatation_start.");

				        -o-transform: rotate(".$bahon_animated_image_rotatation_start.");

				        transform: rotate(".$bahon_animated_image_rotatation_start.");

				    }

				}            

			</style>

			";

		}

	?>



	<div class="bahon-elementor-round-image-widget">

		<img src="<?php echo esc_url($bahon_round_image); ?>"/>

	</div>

	<?php

}



}

