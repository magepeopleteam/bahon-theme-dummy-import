<?php
namespace Bahon\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class BahonPageHeaderWidget extends Widget_Base {

	public function get_name() {
		return 'bahon-page-header-widget';
	}

	public function get_title() {
		return __( 'Bahon Page Header', 'bahon-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-header';
	}

	public function get_categories() {
		return [ 'bahon-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'bahon_page_header_settings',
			[
				'label' => __( 'Bahon Page Header Settings', 'bahon-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'bahon_page_header_bg_image',
			[
				'label' => __( 'Background Image', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'bahon_page_header_bg_size',
			[
				'label' 		=> __( 'Background Size', 'bahon-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'cover',				
				'options' 		=> [
					'cover' 		=> __( 'Cover', 'bahon-elementor-kits' ),
					'contain' 		=> __( 'Contain', 'bahon-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'bahon_page_header_bg_position',
			[
				'label' 		=> __( 'Background Position', 'bahon-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'center',				
				'options' 		=> [
					'top' 		=> __( 'Top', 'bahon-elementor-kits' ),
					'center' 		=> __( 'Center', 'bahon-elementor-kits' ),
					'bottom' 		=> __( 'Bottom', 'bahon-elementor-kits' ),
					'left' 		=> __( 'Left', 'bahon-elementor-kits' ),
					'right' 		=> __( 'Right', 'bahon-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'bahon_page_header_bg_repeat',
			[
				'label' 		=> __( 'Background Repeat', 'bahon-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'no-repeat',				
				'options' 		=> [
					'repeat' 		=> __( 'Repeat', 'bahon-elementor-kits' ),
					'repeat-x' 		=> __( 'Repeat-x', 'bahon-elementor-kits' ),
					'repeat-y' 		=> __( 'Repeat-y', 'bahon-elementor-kits' ),
					'no-repeat' 		=> __( 'No-repeat', 'bahon-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'bahon_page_header_text_color',
			[
				'label' => __( 'Text Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bread-crumb h4, .bread-crumb h4 a, .bread-crumb i' => 'color: {{VALUE}};',
				],
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'bahon_page_header_text_typography',
				'label' => __( 'Text Typography', 'bahon-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .bread-crumb h4, .bread-crumb h4 a',
			]
        );

        $this->end_controls_section();
	
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$bahon_page_header_bg_image = $settings['bahon_page_header_bg_image']['url'] ;
		$bahon_page_header_bg_size = $settings['bahon_page_header_bg_size'] ;
		$bahon_page_header_bg_position = $settings['bahon_page_header_bg_position'] ;
		$bahon_page_header_bg_repeat = $settings['bahon_page_header_bg_repeat'] ;
		if($bahon_page_header_bg_image || $bahon_page_header_bg_size || $bahon_page_header_bg_position || $bahon_page_header_bg_repeat){
			echo "
			<style>
			.page-top-banner {
			    background-image: url(".$bahon_page_header_bg_image.");
			    background-size: ".$bahon_page_header_bg_size.";
			    background-position: ".$bahon_page_header_bg_position.";
			    background-repeat: ".$bahon_page_header_bg_repeat.";
			}
			</style>
			";
		}
	?>
	<div class="bahon-elementor-page-header-widget">
		<?php bahon_page_header_function(); ?>
	</div>
	<?php
}

}
