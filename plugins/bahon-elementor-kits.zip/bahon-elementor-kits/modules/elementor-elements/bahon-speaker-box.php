<?php
namespace Bahon\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Background;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Group_Control_Border;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class BahonSpeakerBoxWidget extends Widget_Base {

	public function get_name() {
		return 'bahon-speaker-box-widget';
	}

	public function get_title() {
		return __( 'Bahon Event Speaker Box', 'bahon-elementor-kits' );
	}

	public function get_icon() {
		return ' eicon-image-box';
	}

	public function get_categories() {
		return [ 'bahon-elements' ];
	}

	protected function _register_controls() {

/***********************
Bahon Speaker Settings
***********************/

		$this->start_controls_section(
			'bahon_speaker_box_settings',
			[
				'label' => __( 'Bahon Speaker Settings', 'bahon-elementor-kits' ),
			]
		);

		$this->add_control(
			'bahon_speaker_name',
			[
				'label' => __( 'Speaker Name', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter speaker name', 'bahon-elementor-kits' ),
				'default' => __( 'Dale Marke', 'bahon-elementor-kits' ),
			]
		);
		$this->add_control(
			'bahon_speaker_designation',
			[
				'label' => __( 'Speaker Designation', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter speaker designation', 'bahon-elementor-kits' ),
				'default' => __( 'Event Manager', 'bahon-elementor-kits' ),
			]
		);
		$this->add_control(
			'bahon_speaker_image',
			[
				'label' => __( 'Speaker Image', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => BAHON_ELEMENTOR_KITS_ASSETS . 'images/speaker-6.jpg',
				],
			]
		);
		$this->add_control(
			'bahon_speaker_facebook_link',
			[
				'label' => __( 'Facebook Profile Link', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'bahon-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'bahon_speaker_twitter_link',
			[
				'label' => __( 'Twitter Profile Link', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'bahon-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'bahon_speaker_linkedin_link',
			[
				'label' => __( 'Linkedin Profile Link', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'bahon-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'bahon_speaker_instagram_link',
			[
				'label' => __( 'Instagram Profile Link', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'bahon-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'bahon_speaker_details_link',
			[
				'label' => __( 'Speaker Details Page Link', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'bahon-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);												
        $this->end_controls_section();

/******************************
Bahon Speaker Style Settings
******************************/

		$this->start_controls_section(
			'bahon_speaker_box_style_settings',
			[
				'label' => __( 'Bahon Speaker Box Style', 'bahon-elementor-kits' ),
			]
		);
		$this->add_control(
			'bahon_speaker_name_color',
			[
				'label' => __( 'Speaker Name Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-speaker-box-widget .name a' => ' color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'bahon_speaker_name_typography',
				'label' => __( 'Speaker Name Typography', 'bahon-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .bahon-elementor-speaker-box-widget .name',
			]
		);
		$this->add_control(
			'bahon_speaker_designation_color',
			[
				'label' => __( 'Speaker Designation Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-speaker-box-widget .designation' => ' color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'bahon_speaker_designation_typography',
				'label' => __( 'Speaker Designation Typography', 'bahon-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .bahon-elementor-speaker-box-widget .designation',
			]
		);
		$this->add_control(
			'bahon_speaker_box_social_icons_color',
			[
				'label' => __( 'Social Icons Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-speaker-box-widget .social-links li a i' => ' color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bahon_speaker_box_social_icons_bgcolor',
				'label' => __( 'Social Icons Background', 'bahon-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .bahon-elementor-speaker-box-widget .social-links li a i',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'bahon_speaker_box_social_icons_hover_color',
			[
				'label' => __( 'Social Icons Hover Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-speaker-box-widget .social-links li a:hover i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bahon_speaker_box_social_icons_hover_bg',
				'label' => __( 'Social Icons Hover Background', 'bahon-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .bahon-elementor-speaker-box-widget .social-links li a:hover i',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);
		$this->add_control(
			'bahon_speaker_box_hover_bg',
			[
				'label' => __( 'Speaker Box Hover Background', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-speaker-box-widget .speaker-block .info-box' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'bahon_speaker_box_border_radius',
			[
				'label' => __( 'Border Radius', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-speaker-box-widget .speaker-block .inner-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_group_control(
        	\Elementor\Group_Control_Box_Shadow::get_type(), 
        	[
        		'name' => 'bahon_speaker_box_shadow', 
        		'selector' => '{{WRAPPER}} .bahon-elementor-speaker-box-widget  .speaker-block .inner-box',
        	]
        );
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'bahon_speaker_box_border',
				'selector' => '{{WRAPPER}} .bahon-elementor-speaker-box-widget .speaker-block .inner-box',
				'separator' => 'before',
			]
		);
        $this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$bahon_speaker_name = $settings['bahon_speaker_name'];
		$bahon_speaker_designation = $settings['bahon_speaker_designation'];
		$bahon_speaker_facebook_link = $settings['bahon_speaker_facebook_link']['url'];
		$bahon_speaker_twitter_link = $settings['bahon_speaker_twitter_link']['url'];
		$bahon_speaker_linkedin_link = $settings['bahon_speaker_linkedin_link']['url'];
		$bahon_speaker_instagram_link = $settings['bahon_speaker_instagram_link']['url'];
		$bahon_speaker_details_link = $settings['bahon_speaker_details_link']['url'];
		$bahon_speaker_image = $settings['bahon_speaker_image']['url'];
	?>

	<div class="bahon-elementor-speaker-box-widget">
	<div class="speaker-block">
	   <div class="inner-box">
	      <div class="image-box">
	         <figure class="image"><a href="<?php echo esc_url($bahon_speaker_details_link); ?>"><img src="<?php echo esc_url($bahon_speaker_image); ?>" alt="<?php echo $bahon_speaker_name; ?>"></a></figure>
	      </div>
	      <div class="info-box">
	         <div class="inner">
	         	<?php if($bahon_speaker_name) { ?>
	            <h4 class="name"><a href="<?php echo esc_url($bahon_speaker_details_link); ?>"><?php echo $bahon_speaker_name; ?></a></h4>
	            <?php } ?>
	            <?php if($bahon_speaker_designation) { ?>
	            <span class="designation"><?php echo $bahon_speaker_designation; ?></span>
	            <?php } ?>
	            <ul class="social-links social-icon-colored">
	            <?php if($bahon_speaker_facebook_link) { ?>
	               <li><a href="<?php echo esc_url($bahon_speaker_facebook_link); ?>"><i class="fab fa-facebook-f"></i></a></li>
	            <?php } ?>
	            <?php if($bahon_speaker_twitter_link) { ?>
	               <li><a href="<?php echo esc_url($bahon_speaker_twitter_link); ?>"><i class="fab fa-twitter"></i></a></li>
	            <?php } ?>
	            <?php if($bahon_speaker_linkedin_link) { ?>   
	               <li><a href="<?php echo esc_url($bahon_speaker_linkedin_link); ?>"><i class="fab fa-linkedin-in"></i></a></li>
	            <?php } ?>
	            <?php if($bahon_speaker_instagram_link) { ?>    
	               <li><a href="<?php echo esc_url($bahon_speaker_instagram_link); ?>"><i class="fab fa-instagram"></i></a></li>
	            <?php } ?>   
	            </ul>
	         </div>
	      </div>
	   </div>
	</div>		
	</div>
	<?php
}

}
