<?php

namespace Bahon;

class BahonElementor {
	
	private static $_instance = null;
	
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		
		return self::$_instance;
	}
	
	
	public function add_widget_categories( $elements_manager ) {
		
		$elements_manager->add_category(
			'bahon-elements',
			[
				'title' => __( 'Bahon Elements', 'bahon-elementor-kits'),
				'icon'  => 'fa fa-plug',
			]
		);
		
	}
	
	private function include_widgets_files() {
		require_once( __DIR__ . '/bahon-page-header.php' );		
		require_once( __DIR__ . '/bahon-countdown.php' );		
		require_once( __DIR__ . '/bahon-round-image.php' );		
		require_once( __DIR__ . '/bahon-animated-aboutus-section.php' );		
		require_once( __DIR__ . '/bahon-speaker-box.php' );		
		require_once( __DIR__ . '/bahon-pricing-table.php' );		
		require_once( __DIR__ . '/bahon-video-popup.php' );		
		require_once( __DIR__ . '/bahon-blog-section.php' );		
		require_once( __DIR__ . '/bahon-newsletter.php' );		
		require_once( __DIR__ . '/bahon-contact-form.php' );		
	}
	
	public function register_widgets() {
		
		// Its is now safe to include Widgets files
		$this->include_widgets_files();
		
		// Register Widgets		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonPageHeaderWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonCountdownWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonRoundImageWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonAnimatedAboutSecWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonSpeakerBoxWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonPricingTableWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonVideoPopupWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonBlogSectionWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonNewsletterWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\BahonContactFormWidget() );
	}
	
	public function __construct() {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        if ( \is_plugin_active( 'elementor/elementor.php' ) ) {
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_widget_categories' ] );
        }
	}
}


// Instantiate Plugin Class
BahonElementor::instance();
