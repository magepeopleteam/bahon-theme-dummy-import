<?php

namespace Bahon\Widgets;



use Elementor\Widget_Base;

use Elementor\Controls_Manager;

use Elementor\Group_Control_Background;

use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



/**

 * @since 1.1.0

 */

class BahonNewsletterWidget extends Widget_Base {



	public function get_name() {

		return 'bahon-newsletter-widget';

	}



	public function get_title() {

		return __( 'Bahon Newsletter', 'bahon-elementor-kits' );

	}



	public function get_icon() {

		return 'eicon-mailchimp';

	}



	public function get_categories() {

		return [ 'bahon-elements' ];

	}



	protected function _register_controls() {



		$this->start_controls_section(

			'bahon_newsletter_settings',

			[

				'label' => __( 'Bahon Newsletter Settings', 'bahon-elementor-kits' ),

				'tab' => Controls_Manager::TAB_CONTENT,

			]

		);

		$this->add_control(

			'bahon_newsletter_mailchimp_api',

			[

				'label' => __( 'MailChimp API Key','bahon-elementor-kits' ),

				'description' => 'The unique API Key of your MailChimp account. <a href="https://mailchimp.com/help/about-api-keys/" target="_blank">Find Your API Key!</a>',

				'type' => Controls_Manager::TEXT,

				'default' => '',

			]

		);

		$this->add_control(

			'bahon_newsletter_mailchimp_listid',

			[

				'label' => __( 'MailChimp List ID','bahon-elementor-kits' ),

				'description' => 'The unique List ID of your MailChimp account. <a href="https://mailchimp.com/help/find-your-list-id/" target="_blank">Find Your List ID!</a>',				

				'type' => Controls_Manager::TEXT,

				'default' => '',

			]

		);

		$this->add_control(

			'bahon_newsletter_double_optin_switch',

			[

				'label'   => __( 'On/Off MailChimp Double Optin', 'bahon-elementor-kits' ),

				'type'    => Controls_Manager::SELECT,

				'default' => 'true',

				'options' => [

					'true'  => 'On',

					'false' => 'Off'

				],

			]

		);																		

        $this->end_controls_section();



		$this->start_controls_section(

			'bahon_newsletter_style',

			[

				'label' => __( 'Bahon Newsletter Style', 'bahon-elementor-kits' ),

				'tab' => Controls_Manager::TAB_STYLE,

			]

		);

		$this->add_control(

			'bahon_newsletter_notice_text_color',

			[

				'label' => __( 'Notice Text Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'default' => '',

				'selectors' => [

					'{{WRAPPER}} .bahon-elementor-newsletter-widget .mailchimp_result' => 'color: {{VALUE}};',

				],

			]

		);

		$this->add_control(

			'divider1',

			[

				'type' => Controls_Manager::DIVIDER,

			]

		);				

		$this->add_control(

			'bahon_newsletter_button_text_color',

			[

				'label' => __( 'Button Text Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'default' => '',

				'selectors' => [

					'{{WRAPPER}} .bahon-elementor-newsletter-widget .subscribe-btn' => 'color: {{VALUE}};',

				],

			]

		);



		$this->add_group_control(

			Group_Control_Background::get_type(),

			[

				'name' => 'bahon_newsletter_button_bg',

				'label' => __( 'Button Background', 'bahon-elementor-kits' ),

				'types' => [ 'classic', 'gradient' ],

				'exclude' => [ 'image' ],

				'selector' => '{{WRAPPER}} .bahon-elementor-newsletter-widget .subscribe-btn',

				'fields_options' => [

					'background' => [

						'default' => 'classic',

					],

				],

			]

		);



		$this->add_control(

			'bahon_newsletter_button_hover_color',

			[

				'label' => __( 'Button Hover Text Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-elementor-newsletter-widget .subscribe-btn:hover' => 'color: {{VALUE}};',

				],

			]

		);



		$this->add_group_control(

			Group_Control_Background::get_type(),

			[

				'name' => 'bahon_newsletter_button_background_hover',

				'label' => __( 'Button Hover Background', 'bahon-elementor-kits' ),

				'types' => [ 'classic', 'gradient' ],

				'exclude' => [ 'image' ],

				'selector' => '{{WRAPPER}} .bahon-elementor-newsletter-widget .subscribe-btn:hover',

				'fields_options' => [

					'background' => [

						'default' => 'classic',

					],

				],

			]

		);        		        		       		        		        		        								

		$this->add_group_control(

			Group_Control_Typography::get_type(),

			[

				'name' => 'bahon_newsletter_button_typography',

				'label' => __( 'Button Typography', 'bahon-elementor-kits' ),


				'selector' => '{{WRAPPER}} .bahon-elementor-newsletter-widget .subscribe-btn',

			]

        );		

        $this->end_controls_section();		                

	}



	protected function render() {



		$settings = $this->get_settings_for_display();

		$bahon_newsletter_mailchimp_api = $settings['bahon_newsletter_mailchimp_api'];

		$bahon_newsletter_mailchimp_listid = $settings['bahon_newsletter_mailchimp_listid'];

		$bahon_newsletter_double_optin = $settings['bahon_newsletter_double_optin_switch'];

	?>



	<div class="bahon-elementor-newsletter-widget">

    <?php echo do_shortcode('[bahon_newsletter api="'.$bahon_newsletter_mailchimp_api.'" listid="'.$bahon_newsletter_mailchimp_listid.'" double_optin="'.$bahon_newsletter_double_optin.'"]'); ?>

	</div>



	<?php

}



}

