<?php

namespace Bahon\Widgets;



use Elementor\Widget_Base;

use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



/**

 * @since 1.1.0

 */

class BahonBlogSectionWidget extends Widget_Base {



	public function get_name() {

		return 'bahon-blog-section-widget';

	}



	public function get_title() {

		return __( 'Bahon Blog', 'bahon-elementor-kits' );

	}



	public function get_icon() {

		return 'eicon-posts-grid';

	}



	public function get_categories() {

		return [ 'bahon-elements' ];

	}



	protected function _register_controls() {



		$this->start_controls_section(

			'bahon_blog_section_settings',

			[

				'label' => __( 'Bahon Blog Section Settings', 'bahon-elementor-kits' ),

				'tab' => Controls_Manager::TAB_CONTENT,

			]

		);

		$this->add_control(

			'bahon_blog_categories',

			[

				'label' => __( 'Choose Categories', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::SELECT2,

				'multiple' => true,

				'default' => '0',

				'options' => vek_blog_get_categories(),			

				'separator' => 'none',

			]

		);

		$this->add_control(

			'bahon_blog_item_show',

			[

				'label' => __( 'No. of Blog Post Show','bahon-elementor-kits' ),

				'type' => Controls_Manager::NUMBER,

				'default' => __( '3', 'bahon-elementor-kits' ),

			]

		);

		$this->add_control(

			'bahon_blog_excerpt_limit',

			[

				'label' => __( 'Post Description Word Limit','bahon-elementor-kits' ),

				'type' => Controls_Manager::NUMBER,

				'default' => __( '15', 'bahon-elementor-kits' ),

			]

		);

		$this->add_control(

			'bahon_blog_post_order',

			[

				'label' => __( 'Post Order', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::SELECT,

				'default' => 'DESC',

				'options' => ['DESC' => 'Descending', 'ASC' => 'Ascending'],			

				'separator' => 'none',

			]

		);

		$this->add_control(

			'bahon_blog_post_orderby',

			[

				'label' => __( 'Post Orderby', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::SELECT,

				'default' => 'date',

				'options' => ['date' => 'Date', 'title' => 'Title', 'rand' => 'Random', 'ID' => 'ID', 'ID' => 'ID'],	

				'separator' => 'none',

			]

		);

		$this->add_control(

			'bahon_blog_post_date_format',

			[

				'label' => __( 'Date Format', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::SELECT,

				'default' => 'style1',

				'options' => ['wp' => 'WordPress Default', 'style1' => 'Style-1'],			

				'separator' => 'none',

			]

		);																						

        $this->end_controls_section();

		$this->start_controls_section(

			'bahon_blog_section_style',

			[

				'label' => __( 'Bahon Blog Section Style', 'bahon-elementor-kits' ),

				'tab' => Controls_Manager::TAB_STYLE,

			]

		);

		$this->add_control(

			'bahon_blog_post_date_text_color',

			[

				'label' => __( 'Date Text Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-date' => 'color: {{VALUE}};',

				],

			]

        );

		$this->add_control(

			'bahon_blog_post_date_bg',

			[

				'label' => __( 'Date Background', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-date' => 'background-color: {{VALUE}};',

				],

			]

        );

		$this->add_control(

			'bahon_blog_post_date_hover_text_color',

			[

				'label' => __( 'Date Hover Text Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-date:hover' => 'color: {{VALUE}};',

				],

			]

        );        

		$this->add_control(

			'bahon_blog_post_date_hover_bg',

			[

				'label' => __( 'Date Hover Background', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-date:hover' => 'background-color: {{VALUE}};',

				],

			]

        );

		$this->add_control(

			'divider1',

			[

				'type' => Controls_Manager::DIVIDER,

			]

		);        

		$this->add_control(

			'bahon_blog_post_meta_icon_color',

			[

				'label' => __( 'Meta Box Icon Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-author-n-comments i' => 'color: {{VALUE}};',

				],

			]

        );        

		$this->add_control(

			'bahon_blog_post_meta_text_color',

			[

				'label' => __( 'Meta Box Text Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-author-n-comments span' => 'color: {{VALUE}};',

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-author-n-comments span a' => 'color: {{VALUE}};',

				],

			]

        );        

		$this->add_control(

			'bahon_blog_post_meta_bg',

			[

				'label' => __( 'Meta Box Background', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-author-n-comments' => 'background-color: {{VALUE}};',

				],

			]

        );

		$this->add_control(

			'divider2',

			[

				'type' => Controls_Manager::DIVIDER,

			]

		);        

		$this->add_control(

			'bahon_blog_post_title_color',

			[

				'label' => __( 'Post Title Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-title' => 'color: {{VALUE}};',

				],

			]

        );

		$this->add_group_control(

			Group_Control_Typography::get_type(),

			[

				'name' => 'bahon_blog_post_title_typography',

				'label' => __( 'Post Title Typography', 'bahon-elementor-kits' ),


				'selector' => '{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-title',

			]

        );

		$this->add_control(

			'divider3',

			[

				'type' => Controls_Manager::DIVIDER,

			]

		);        

		$this->add_control(

			'bahon_blog_post_desc_color',

			[

				'label' => __( 'Post Description Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-excerpt' => 'color: {{VALUE}};',

				],

			]

        );

		$this->add_group_control(

			Group_Control_Typography::get_type(),

			[

				'name' => 'bahon_blog_post_desc_typography',

				'label' => __( 'Post Description Typography', 'bahon-elementor-kits' ),


				'selector' => '{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-excerpt',

			]

        );

		$this->add_control(

			'divider4',

			[

				'type' => Controls_Manager::DIVIDER,

			]

		);

		$this->add_control(

			'bahon_blog_post_content_bg',

			[

				'label' => __( 'Post Content Background Color', 'bahon-elementor-kits' ),

				'type' => Controls_Manager::COLOR,

				'selectors' => [

					'{{WRAPPER}} .bahon-blog-section .blog-post-item-1 .post-content' => 'background-color: {{VALUE}};',

				],

			]

        );		                                       

		$this->end_controls_section();			

	}



	protected function render() {



		$settings = $this->get_settings_for_display();

		$bahon_blog_categories = $settings['bahon_blog_categories'];

		$bahon_blog_item_show = $settings['bahon_blog_item_show'];

		$bahon_blog_excerpt_limit = $settings['bahon_blog_excerpt_limit'];

		$bahon_blog_post_order = $settings['bahon_blog_post_order'];

		$bahon_blog_post_orderby = $settings['bahon_blog_post_orderby'];

		$bahon_blog_post_date_format = $settings['bahon_blog_post_date_format'];

		if($bahon_blog_categories){

			$cat_string = implode(", ", $bahon_blog_categories);			

		} else {

			$cat_string = '';

		}



	?>



	<div class="bahon-elementor-blog-section-widget">



		<?php echo do_shortcode('[bahon_blog category="'.$cat_string.'" num_post="'.$bahon_blog_item_show.'" word_limit="'.$bahon_blog_excerpt_limit.'" order="'.$bahon_blog_post_order.'" orderby="'.$bahon_blog_post_orderby.'" date_format="'.$bahon_blog_post_date_format.'" ]'); 

        ?>

	</div>



	<?php

	}

}

