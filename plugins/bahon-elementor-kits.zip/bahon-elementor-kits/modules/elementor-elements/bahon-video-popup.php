<?php
namespace Bahon\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class BahonVideoPopupWidget extends Widget_Base {

	public function get_name() {
		return 'bahon-video-popup-widget';
	}

	public function get_title() {
		return __( 'Bahon Video Popup', 'bahon-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-play';
	}

	public function get_categories() {
		return [ 'bahon-elements' ];
	}

	protected function _register_controls() {

/******************************************************************
Bahon Video Popup Settings
*******************************************************************/

		$this->start_controls_section(
			'bahon_video_popup_settings',
			[
				'label' => __( 'Bahon Video Popup Settings', 'bahon-elementor-kits' ),
			]
		);
		$this->add_control(
			'bahon_video_popup_type',
			[
				'label' 		=> __( 'Choose Video Type', 'bahon-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'youtube',				
				'options' 		=> [
					'youtube' 	=> __( 'Youtube', 'bahon-elementor-kits' ),
					'vimeo' 	=> __( 'Vimeo', 'bahon-elementor-kits' ),
				],
			]
		);
		$this->add_control(
			'bahon_video_popup_youtube_id',
			[
				'label' 		=> __( 'Youtube Video ID', 'bahon-elementor-kits' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> __( 'aqz-KE-bpKQ', 'bahon-elementor-kits' ),
				'default' 		=> __( 'aqz-KE-bpKQ', 'bahon-elementor-kits' ),
				'condition' 	=> ['bahon_video_popup_type' => 'youtube'],
			]
		);
		$this->add_control(
			'bahon_video_popup_vimeo_id',
			[
				'label' 		=> __( 'Vimeo Video ID', 'bahon-elementor-kits' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> __( '588496072', 'bahon-elementor-kits' ),
				'default' 		=> __( '588496072', 'bahon-elementor-kits' ),
				'condition' 	=> ['bahon_video_popup_type' => 'vimeo'],
			]
		);
		$this->add_control(
			'bahon_video_popup_icon',
			[
				'label' 		=> __( 'Choose Icon', 'bahon-elementor-kits' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 	=> 'flaticon flaticon-play-button-3',
					'library' 	=> 'bahon-icons',
				],
			]
		);															
        $this->end_controls_section();

		$this->start_controls_section(
			'bahon_video_popup_style',
			[
				'label' => __( 'Bahon Video Popup Style', 'bahon-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'bahon_video_popup_icon_color',
			[
				'label' => __( 'Icon Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-video-popup-widget i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'bahon_video_popup_icon_bg',
			[
				'label' => __( 'Icon Background', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-video-popup-widget i' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'bahon_video_popup_icon_font_size',
			[
				'label' => __( 'Icon Font Size', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-video-popup-widget i' => 'font-size: {{VALUE}}px;',
				],
			]
		);
		$this->add_responsive_control(
			'bahon_video_popup_icon_width',
			[
				'label' => __( 'Icon Width (px)', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-video-popup-widget i' => 'width: {{VALUE}}px;height: {{VALUE}}px;line-height: {{VALUE}}px',
					'.bahon-elementor-video-popup-widget .link-lightbox .ripple' => 'width: {{VALUE}}px;height: {{VALUE}}px',
					'.bahon-elementor-video-popup-widget .link-lightbox .ripple:before' => 'width: {{VALUE}}px;height: {{VALUE}}px',
					'.bahon-elementor-video-popup-widget .link-lightbox .ripple:after' => 'width: {{VALUE}}px;height: {{VALUE}}px',
				],
			]
		);												
        $this->end_controls_section();		        
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$bahon_video_popup_type = $settings['bahon_video_popup_type'];
		$bahon_video_popup_youtube_id = $settings['bahon_video_popup_youtube_id'];
		$bahon_video_popup_vimeo_id = $settings['bahon_video_popup_vimeo_id'];
		$bahon_video_popup_icon = $settings['bahon_video_popup_icon']['value'];
	?>

	<div class="bahon-elementor-video-popup-widget">
	<?php if($bahon_video_popup_type == 'youtube') { ?>

		<a href="#" class="link-lightbox" data-videoid="<?php echo esc_attr($bahon_video_popup_youtube_id); ?>" data-videosite="youtube"><i class="<?php echo $bahon_video_popup_icon; ?>"></i><span class="ripple"></span></a>

	<?php } else { ?>

		<a href="#" class="link-lightbox" data-videoid="<?php echo esc_attr($bahon_video_popup_vimeo_id); ?>" data-videosite="vimeo"><i class="<?php echo $bahon_video_popup_icon; ?>"></i><span class="ripple"></span></a>

	<?php } ?>
	</div>

	<?php
}

}
