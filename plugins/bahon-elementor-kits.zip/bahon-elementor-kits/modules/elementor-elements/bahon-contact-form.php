<?php
namespace Bahon\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class BahonContactFormWidget extends Widget_Base {

	public function get_name() {
		return 'bahon-contact-form-widget';
	}

	public function get_title() {
		return __( 'Bahon Contact Form', 'bahon-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return [ 'bahon-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'bahon_contact_form_settings',
			[
				'label' => __( 'Bahon Contact Form Settings', 'bahon-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'bahon_contact_form_subject',
			[
				'label' => __( 'Form Subject','bahon-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => 'New Entry: Contact Us',
			]
		);
		$this->add_control(
			'bahon_contact_form_recipient_email',
			[
				'label' => __( 'Form Recipient Email','bahon-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => get_option( 'admin_email' ),
			]
		);
		$this->add_control(
			'bahon_contact_form_btn_label',
			[
				'label' => __( 'Form Button Label','bahon-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Send Message',
			]
		);																			
        $this->end_controls_section();
        
		$this->start_controls_section(
			'bahon_contact_form_style',
			[
				'label' => __( 'Bahon Contact Form Style', 'bahon-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);				
		$this->add_control(
			'bahon_contact_form_button_text_color',
			[
				'label' => __( 'Button Text Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-contact-form-widget #vek_cf_btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bahon_contact_form_button_bg',
				'label' => __( 'Button Background', 'bahon-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .bahon-elementor-contact-form-widget #vek_cf_btn',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'bahon_contact_form_button_hover_color',
			[
				'label' => __( 'Button Hover Text Color', 'bahon-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bahon-elementor-contact-form-widget #vek_cf_btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bahon_contact_form_button_background_hover',
				'label' => __( 'Button Hover Background', 'bahon-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .bahon-elementor-contact-form-widget #vek_cf_btn:hover',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);        		        		       		        		        		        								
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'bahon_contact_form_button_typography',
				'label' => __( 'Button Typography', 'bahon-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .bahon-elementor-contact-form-widget #vek_cf_btn',
			]
        );		
        $this->end_controls_section();		                
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$bahon_contact_form_subject = $settings['bahon_contact_form_subject'];
		$bahon_contact_form_recipient_email = $settings['bahon_contact_form_recipient_email'];
		$bahon_contact_form_btn_label = $settings['bahon_contact_form_btn_label'];
	?>

	<div class="bahon-elementor-contact-form-widget">
    <?php echo do_shortcode('[bahon_contact_form subject="'.$bahon_contact_form_subject.'" recipient="'.$bahon_contact_form_recipient_email.'" btn_label="'.$bahon_contact_form_btn_label.'"]'); ?>
	</div>

	<?php
}

}
